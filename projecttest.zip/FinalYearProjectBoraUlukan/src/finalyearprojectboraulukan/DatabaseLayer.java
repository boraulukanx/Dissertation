package finalyearprojectboraulukan;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bora
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class DatabaseLayer {
    
    public static ResultSet executeSelect(String query){
        ResultSet rs = null;
        try{  
            //Setting connection
            Class.forName("com.mysql.jdbc.Driver");
            String connectionUrl = "jdbc:mysql://35.246.56.64:3306/gcsdatabase?serverTimezone=UTC"; 
            Connection con = DriverManager.getConnection(connectionUrl,"root","bora2000");
            System.out.println("Connected");
            
            //Using SQL to retrieve data
            PreparedStatement pstmt = null;

            //SQL query command
            
            pstmt = con.prepareStatement(query);
            rs = pstmt.executeQuery();
            
         } 
        catch (SQLException e) 
        {
            System.out.println("SQL Exception: "+ e.toString());
        } 
        catch (ClassNotFoundException cE) 
        {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
                        
        return rs;
    }
    
    public static void executeInsert(String query){ 
            
        try{
            //Setting SQL connection
            Class.forName("com.mysql.jdbc.Driver");
            String connectionUrl = "jdbc:mysql://35.246.56.64:3306/gcsdatabase?serverTimezone=UTC"; 
            Connection con = DriverManager.getConnection(connectionUrl,"root","bora2000");
            System.out.println("Connected");

            PreparedStatement pstmt = con.prepareStatement(query);
           
            pstmt.execute();
    
        }
        catch (SQLException e)
        {
            System.out.println("SQL Exception: "+ e.toString());
        }
        catch (ClassNotFoundException cE)
        {
            System.out.println("Class Not Found Exception: "+ cE.toString());
        }
    }
    
}
